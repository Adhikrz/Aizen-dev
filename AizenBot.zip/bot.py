
from pyrogram import Client, filters
from pyrogram.types import Message
from pytgcalls import PyTgCalls
from pytgcalls.types.input_stream import AudioPiped
import yt_dlp, os, random

api_id = 23934798
api_hash = "80dfe949fadab1a4fe45fa5aef0066eb"
bot_token = "8004773762:AAE-pfLilFt1hq6Wp6h0ajnjwaWzr9RsSwc"

app = Client("Aizen", api_id=api_id, api_hash=api_hash, bot_token=bot_token)
call_pyro = PyTgCalls(app)

WATERMARK = "@SENBONZAKURAH"
afk_users = {}
warnings = {}

@app.on_message(filters.command("joinvc"))
async def join_vc(client, message: Message):
    await call_pyro.join_group_call(message.chat.id, AudioPiped("silence.mp3"))
    await message.reply(f"Joined VC. {WATERMARK}")

@app.on_message(filters.command("leavevc"))
async def leave_vc(client, message: Message):
    await call_pyro.leave_group_call(message.chat.id)
    await message.reply(f"Left VC. {WATERMARK}")

@app.on_message(filters.command("play"))
async def play_audio(client, message: Message):
    chat_id = message.chat.id
    if message.reply_to_message and message.reply_to_message.audio:
        path = await message.reply_to_message.download()
    elif len(message.command) > 1:
        url = message.text.split(None, 1)[1]
        path = download_youtube_audio(url)
    else:
        await message.reply("Reply to an audio or give a YouTube URL.")
        return
    await call_pyro.join_group_call(chat_id, AudioPiped(path))
    await message.reply(f"Now playing. {WATERMARK}")

@app.on_message(filters.command("stop"))
async def stop_audio(client, message: Message):
    await call_pyro.leave_group_call(message.chat.id)
    await message.reply(f"Stopped playback. {WATERMARK}")

@app.on_message(filters.command("ban") & filters.reply)
async def ban_user(client, message: Message):
    user_id = message.reply_to_message.from_user.id
    await client.ban_chat_member(message.chat.id, user_id)
    await message.reply(f"User banned. {WATERMARK}")

@app.on_message(filters.command("mute") & filters.reply)
async def mute_user(client, message: Message):
    user_id = message.reply_to_message.from_user.id
    await client.restrict_chat_member(message.chat.id, user_id, permissions={"can_send_messages": False})
    await message.reply(f"User muted. {WATERMARK}")

@app.on_message(filters.command("warn") & filters.reply)
async def warn_user(client, message: Message):
    user_id = message.reply_to_message.from_user.id
    user_name = message.reply_to_message.from_user.mention
    chat_id = message.chat.id
    warnings.setdefault(chat_id, {}).setdefault(user_id, 0)
    warnings[chat_id][user_id] += 1
    if warnings[chat_id][user_id] >= 3:
        await client.ban_chat_member(chat_id, user_id)
        await message.reply(f"{user_name} has been banned after 3 warnings.")
        warnings[chat_id][user_id] = 0
    else:
        await message.reply(f"{user_name} warned. Total: {warnings[chat_id][user_id]}")

@app.on_message(filters.command("afk"))
async def set_afk(client, message: Message):
    reason = message.text.split(None, 1)[1] if len(message.command) > 1 else "AFK"
    afk_users[message.from_user.id] = reason
    await message.reply(f"{message.from_user.mention} is now AFK: {reason}")

@app.on_message(filters.text & ~filters.command(["afk", "play", "joinvc", "leavevc", "stop"]))
async def check_afk(client, message: Message):
    if message.from_user.id in afk_users:
        del afk_users[message.from_user.id]
        await message.reply(f"Welcome back {message.from_user.mention}, AFK removed.")
    for entity in message.entities or []:
        if entity.type == "mention":
            username = message.text[entity.offset: entity.offset + entity.length]
            user = await client.get_users(username)
            if user.id in afk_users:
                await message.reply(f"{username} is AFK: {afk_users[user.id]}")

@app.on_message(filters.command("dice"))
async def dice(client, message):
    await message.reply_dice()

@app.on_message(filters.command("coin"))
async def coin(client, message):
    await message.reply(random.choice(["Heads", "Tails"]))

@app.on_message(filters.command("rps"))
async def rps(client, message):
    await message.reply(random.choice(["Rock", "Paper", "Scissors"]))

@app.on_message(filters.command("truth"))
async def truth(client, message):
    truths = ["What's your biggest fear?", "Who was your first crush?", "Have you ever lied to your best friend?"]
    await message.reply(random.choice(truths))

@app.on_message(filters.command("dare"))
async def dare(client, message):
    dares = ["Text your crush.", "Do 10 push-ups.", "Sing a song and send it."]
    await message.reply(random.choice(dares))

def download_youtube_audio(url):
    ydl_opts = {
        'format': 'bestaudio',
        'outtmpl': 'downloads/%(title)s.%(ext)s',
        'noplaylist': True,
        'quiet': True,
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        return ydl.prepare_filename(info).replace('.webm', '.mp3').replace('.m4a', '.mp3')

call_pyro.start()
app.run()
